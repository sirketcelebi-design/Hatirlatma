# Hatırlatma Programı (Android)

İleri tarihli görevleri veya düzenli işleri hatırlatan, uygulama kapalıyken de bildirim gönderen Android uygulaması.
Kotlin + Jetpack Compose, Android 8.0 (API 26) ve üstü.

## APK nasıl alınır?

**Yol 1 – Android Studio (en kolayı)**
1. Android Studio'yu aç → *Open* → bu klasörü seç. İlk açılışta Gradle ve SDK bileşenlerini kendisi indirir.
2. Telefonu USB ile bağla (Geliştirici seçenekleri → USB hata ayıklama açık) ve ▶ *Run*'a bas, **ya da**
3. *Build → Build Bundle(s) / APK(s) → Build APK(s)* ile APK üret.
   Dosya: `app/build/outputs/apk/debug/app-debug.apk` → telefona atıp kur (bilinmeyen kaynaklardan yüklemeye izin ver).

**Yol 2 – Bilgisayara hiçbir şey kurmadan (GitHub)**
1. Bu klasörü yeni bir GitHub deposuna yükle.
2. *Actions* sekmesinde "APK derle" iş akışı kendiliğinden çalışır (yoksa *Run workflow*).
3. Bittiğinde çalışmanın altındaki **hatirlatma-apk** dosyasını indir, içinden `app-debug.apk` çıkar.

**Yol 3 – Komut satırı** (JDK 17 + Android SDK kuruluysa): `gradle assembleDebug`

## Özellikler

- **Ana sayfa**: sağ altta sabit **Ekle**, sol altta sabit **Arşiv** düğmesi (liste kayarken yerinde kalır).
- Her görev tek satır; altında küçük tek satırda *kalan ay/gün/saat* ve *tarih-saat*.
- **Süresi geçen görevler kırmızı**, tamamlanana kadar kırmızı kalır.
- Görev satırına tıklayınca: **Tamamlandı**, **Düzenle** (metin + tarih + saat), tekrarlıysa **Tekrarı iptal et**.
- **Ekle/Düzenle**: metin, tarih (varsayılan bugün), ayrı saat alanı, **Tekrarlı** tiki:
  günlük (saat) · haftalık (gün + saat) · aylık (ayın günü + saat). Ayda olmayan gün (31 gibi) için ayın son günü kullanılır.
- **Tekrarlı görevler** ana sayfada en altta; bir sonraki bildirimin zamanı yazar. Tamamlansa da tamamlanmasa da bir sonraki
  tekrar planlandığı zamanda yine bildirim gönderir.
- **Bildirim** (uygulama kapalıyken de): metin + altında **Tamamlandı** ve **Ertele**.
  Ertele → 5 dk / 15 dk / 30 dk / 1 saat / 3 saat / Yarın seçenekleri.
- **Telefon yeniden başlayınca** alarmlar yeniden kurulur; tamamlanmamış görevlerin bildirimi tekrar gösterilir.
- **Arşiv**: tamamlananlar ve iptal edilen tekrarlılar, iki istatistik kartı (toplam/bu ay tamamlanan; zamanında tamamlama oranı),
  **Geri al** (ana sayfaya döndür) ve **Sil** (silmeden önce onay ister).

## İlk kullanımda dikkat

- Android 13+ cihazlarda açılışta **bildirim izni** istenir; vermezsen hatırlatma çıkmaz (ana sayfada uyarı görünür).
- Xiaomi, Huawei, Oppo, Samsung gibi bazı telefonlar arka plandaki uygulamaları agresif kapatır. Bildirimler zamanında
  gelmezse: *Ayarlar → Uygulamalar → Hatırlatma Programı → Pil* bölümünden **"Kısıtlama yok / Sınırsız"** seç ve varsa
  "otomatik başlatma"yı aç.

## Kod haritası (`app/src/main/java/com/hatirlatma/app`)

| Dosya | Görevi |
|---|---|
| `MainActivity.kt` | Giriş, bildirim izni, ekranlar arası geçiş |
| `HomeScreen.kt` / `EditScreen.kt` / `ArchiveScreen.kt` | Arayüz |
| `Engine.kt` | Kaydet, tamamla, ertele, iptal, geri al, alarm tetiklenince ne olacağı |
| `Scheduler.kt` | AlarmManager ile kesin alarm kurma/iptal |
| `Notifier.kt` | Bildirim (Tamamlandı / Ertele düğmeleri) |
| `Receivers.kt` | Alarm, bildirim düğmesi ve yeniden başlatma alıcıları |
| `SnoozeActivity.kt` | "Ertele" süre seçimi penceresi |
| `Repo.kt`, `Model.kt` | SQLite veritabanı ve veri modeli |
| `Fmt.kt` | Tarih biçimleri, kalan süre, tekrar zamanı hesabı |
