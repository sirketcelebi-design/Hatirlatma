package com.hatirlatma.app

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import kotlinx.coroutines.flow.MutableStateFlow

private class DbHelper(context: Context) : SQLiteOpenHelper(context, "reminders.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE reminders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                text TEXT NOT NULL,
                due_at INTEGER NOT NULL,
                repeat_type INTEGER NOT NULL DEFAULT 0,
                repeat_day INTEGER NOT NULL DEFAULT 0,
                hour INTEGER NOT NULL DEFAULT 0,
                minute INTEGER NOT NULL DEFAULT 0,
                status INTEGER NOT NULL DEFAULT 0,
                occurrence_at INTEGER NOT NULL DEFAULT 0,
                completed_at INTEGER NOT NULL DEFAULT 0,
                pending_at INTEGER NOT NULL DEFAULT 0,
                created_at INTEGER NOT NULL DEFAULT 0
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Şimdilik tek sürüm var.
    }
}

/**
 * Hatırlatmaların tutulduğu yer (SQLite). Hem arayüz hem de alarm/bildirim alıcıları
 * aynı örneği kullanır. [state] değiştiğinde arayüz kendiliğinden yenilenir.
 */
class Repo private constructor(context: Context) {
    private val helper = DbHelper(context)
    private val lock = Any()

    val state = MutableStateFlow<List<Reminder>>(emptyList())

    init {
        reload()
    }

    fun reload() {
        state.value = queryAll()
    }

    fun queryAll(): List<Reminder> = synchronized(lock) {
        val list = ArrayList<Reminder>()
        helper.readableDatabase.query("reminders", null, null, null, null, null, "id ASC").use { c ->
            while (c.moveToNext()) list.add(fromCursor(c))
        }
        list
    }

    fun get(id: Long): Reminder? = synchronized(lock) {
        helper.readableDatabase.query(
            "reminders", null, "id = ?", arrayOf(id.toString()), null, null, null
        ).use { c ->
            if (c.moveToFirst()) fromCursor(c) else null
        }
    }

    fun insert(r: Reminder): Long {
        val id = synchronized(lock) {
            helper.writableDatabase.insert("reminders", null, toValues(r))
        }
        reload()
        return id
    }

    fun update(r: Reminder) {
        synchronized(lock) {
            helper.writableDatabase.update("reminders", toValues(r), "id = ?", arrayOf(r.id.toString()))
        }
        reload()
    }

    fun delete(id: Long) {
        synchronized(lock) {
            helper.writableDatabase.delete("reminders", "id = ?", arrayOf(id.toString()))
        }
        reload()
    }

    private fun toValues(r: Reminder) = ContentValues().apply {
        put("text", r.text)
        put("due_at", r.dueAt)
        put("repeat_type", r.repeat.code)
        put("repeat_day", r.repeatDay)
        put("hour", r.hour)
        put("minute", r.minute)
        put("status", r.status.code)
        put("occurrence_at", r.occurrenceAt)
        put("completed_at", r.completedAt)
        put("pending_at", r.pendingAt)
        put("created_at", r.createdAt)
    }

    private fun Cursor.long(name: String): Long = getLong(getColumnIndexOrThrow(name))
    private fun Cursor.int(name: String): Int = getInt(getColumnIndexOrThrow(name))

    private fun fromCursor(c: Cursor) = Reminder(
        id = c.long("id"),
        text = c.getString(c.getColumnIndexOrThrow("text")),
        dueAt = c.long("due_at"),
        repeat = Repeat.of(c.int("repeat_type")),
        repeatDay = c.int("repeat_day"),
        hour = c.int("hour"),
        minute = c.int("minute"),
        status = Status.of(c.int("status")),
        occurrenceAt = c.long("occurrence_at"),
        completedAt = c.long("completed_at"),
        pendingAt = c.long("pending_at"),
        createdAt = c.long("created_at")
    )

    companion object {
        @Volatile
        private var instance: Repo? = null

        fun of(context: Context): Repo =
            instance ?: synchronized(this) {
                instance ?: Repo(context.applicationContext).also { instance = it }
            }
    }
}
