package com.hatirlatma.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

/** Bildirimin hazırlanması: metin + altında "Tamamlandı" ve "Ertele" düğmeleri. */
object Notifier {
    const val CHANNEL_ID = "reminders"

    fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Hatırlatmalar",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Zamanı gelen hatırlatma bildirimleri"
                enableVibration(true)
            }
            nm.createNotificationChannel(channel)
        }
    }

    fun show(ctx: Context, r: Reminder) {
        ensureChannel(ctx)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) return

        val nid = r.id.toInt()
        val immutableUpdate = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

        val openApp = PendingIntent.getActivity(
            ctx, nid * 10 + 4,
            Intent(ctx, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            immutableUpdate
        )

        val done = PendingIntent.getBroadcast(
            ctx, nid * 10 + 2,
            Intent(ctx, ActionReceiver::class.java).apply {
                action = ActionReceiver.ACTION_DONE
                data = Uri.parse("hatirlatma://reminder/$nid/done")
                putExtra(Scheduler.EXTRA_ID, r.id)
            },
            immutableUpdate
        )

        // "Ertele" → 5 dk / 15 dk / 30 dk / 1 saat ... seçeneklerini gösteren küçük pencere
        val snooze = PendingIntent.getActivity(
            ctx, nid * 10 + 3,
            Intent(ctx, SnoozeActivity::class.java).apply {
                data = Uri.parse("hatirlatma://reminder/$nid/snooze-ui")
                putExtra(Scheduler.EXTRA_ID, r.id)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            },
            immutableUpdate
        )

        val notification = NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Hatırlatma")
            .setContentText(r.text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(r.text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setContentIntent(openApp)
            .setAutoCancel(false)
            .addAction(0, "Tamamlandı", done)
            .addAction(0, "Ertele", snooze)
            .build()

        try {
            NotificationManagerCompat.from(ctx).notify(nid, notification)
        } catch (e: SecurityException) {
            // Bildirim izni verilmemiş; sessizce geç.
        }
    }

    fun cancel(ctx: Context, id: Long) {
        NotificationManagerCompat.from(ctx).cancel(id.toInt())
    }
}
