@file:OptIn(ExperimentalMaterial3Api::class)

package com.hatirlatma.app

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.ZoneId

@Composable
fun ArchiveScreen(all: List<Reminder>, onBack: () -> Unit) {
    val ctx = LocalContext.current

    // Arşiv: tamamlananlar + iptal edilen tekrarlı görevler (en yeni üstte)
    val archived = all.filter { it.status != Status.ACTIVE }.sortedByDescending { it.completedAt }
    val done = archived.filter { it.status == Status.DONE }

    // İstatistik 1: toplam / bu ay tamamlanan görev sayısı
    val monthStart = LocalDate.now().withDayOfMonth(1)
        .atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
    val thisMonth = done.count { it.completedAt >= monthStart }

    // İstatistik 2: zamanında tamamlama oranı (planlanan zamandan en fazla 1 saat sonra = zamanında)
    val onTime = done.count { it.completedAt <= it.occurrenceAt + ON_TIME_GRACE_MS }
    val percent: Int? = if (done.isEmpty()) null else onTime * 100 / done.size

    var toDelete by remember { mutableStateOf<Reminder?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Arşiv", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Geri")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            item {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatCard(
                        title = "Tamamlanan görev",
                        value = done.size.toString(),
                        caption = "Bu ay: $thisMonth",
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "Zamanında tamamlama",
                        value = percent?.let { "%$it" } ?: "—",
                        caption = "En fazla 1 saat gecikmeyle",
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            if (archived.isEmpty()) {
                item {
                    Text(
                        "Arşivde henüz görev yok.",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp)
                    )
                }
            }

            items(archived, key = { it.id }) { r ->
                ArchiveRow(
                    r = r,
                    onRestore = {
                        Engine.restore(ctx, r.id)
                        Toast.makeText(ctx, "Ana sayfaya geri alındı.", Toast.LENGTH_SHORT).show()
                    },
                    onDelete = { toDelete = r }
                )
            }
        }
    }

    // Silmeden önce onay iste
    toDelete?.let { r ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Silinsin mi?") },
            text = {
                Text("\"${r.text}\" kalıcı olarak silinecek. Bu işlem geri alınamaz.", maxLines = 4)
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        Engine.delete(ctx, r.id)
                        toDelete = null
                    }
                ) { Text("Sil", color = OverdueRed) }
            },
            dismissButton = {
                TextButton(onClick = { toDelete = null }) { Text("Vazgeç") }
            }
        )
    }
}

@Composable
private fun StatCard(title: String, value: String, caption: String, modifier: Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(title, fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
            Text(
                value,
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
            Text(caption, fontSize = 11.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
        }
    }
}

@Composable
private fun ArchiveRow(r: Reminder, onRestore: () -> Unit, onDelete: () -> Unit) {
    val sub = if (r.status == Status.DONE) {
        "Tamamlandı: ${Fmt.dateTime(r.completedAt)} · Planlanan: ${Fmt.shortDateTime(r.occurrenceAt)}"
    } else {
        "Tekrar iptal edildi: ${Fmt.dateTime(r.completedAt)} · ${Fmt.repeatLabel(r.repeat)}"
    }

    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    text = r.text,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = sub,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            TextButton(onClick = onRestore) { Text("Geri al") }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Sil", tint = OverdueRed)
            }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
    }
}

private const val ON_TIME_GRACE_MS = 60L * 60L * 1000L
