package com.hatirlatma.app

enum class Repeat(val code: Int) {
    NONE(0), DAILY(1), WEEKLY(2), MONTHLY(3);

    companion object {
        fun of(code: Int): Repeat = values().firstOrNull { it.code == code } ?: NONE
    }
}

enum class Status(val code: Int) {
    ACTIVE(0), DONE(1), CANCELLED(2);

    companion object {
        fun of(code: Int): Status = values().firstOrNull { it.code == code } ?: ACTIVE
    }
}

/**
 * Tek bir hatırlatma kaydı.
 *
 * dueAt        : Bir sonraki bildirimin çıkacağı an (tekrarlı görevde "sonraki" tekrar).
 * occurrenceAt : Planlanan asıl zaman (ertelense bile değişmez; arşiv istatistiği bunu kullanır).
 * pendingAt    : Sadece tekrarlı görevler için. Bildirimi çıkmış ama henüz tamamlanmamış
 *                tekrarın zamanı. 0 ise bekleyen yok. (Doluysa görev kırmızı gösterilir.)
 * repeatDay    : Haftalıkta 1=Pazartesi ... 7=Pazar, aylıkta ayın günü (1-31).
 * completedAt  : Arşivdeki kayıt için tamamlanma (veya tekrar iptal) zamanı.
 */
data class Reminder(
    val id: Long = 0L,
    val text: String,
    val dueAt: Long,
    val repeat: Repeat = Repeat.NONE,
    val repeatDay: Int = 0,
    val hour: Int = 0,
    val minute: Int = 0,
    val status: Status = Status.ACTIVE,
    val occurrenceAt: Long = dueAt,
    val completedAt: Long = 0L,
    val pendingAt: Long = 0L,
    val createdAt: Long = System.currentTimeMillis()
) {
    val isRepeating: Boolean get() = repeat != Repeat.NONE
}
