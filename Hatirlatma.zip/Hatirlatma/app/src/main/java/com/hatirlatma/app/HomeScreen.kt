@file:OptIn(ExperimentalMaterial3Api::class)

package com.hatirlatma.app

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.List
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.delay

@Composable
fun HomeScreen(
    reminders: List<Reminder>,
    notificationsOn: Boolean,
    onFixNotifications: () -> Unit,
    onAdd: () -> Unit,
    onEdit: (Long) -> Unit,
    onArchive: () -> Unit
) {
    val ctx = LocalContext.current

    // Kalan süreler her 30 sn'de bir kendiliğinden yenilenir.
    val now by produceState(initialValue = System.currentTimeMillis()) {
        while (true) {
            delay(30_000L)
            value = System.currentTimeMillis()
        }
    }

    // Tamamlananlar ana sayfada görünmez; tekrarlı görevler listenin en altında durur.
    val active = reminders.filter { it.status == Status.ACTIVE }
    val oneTime = active.filter { !it.isRepeating }.sortedBy { it.dueAt }
    val repeating = active.filter { it.isRepeating }.sortedBy { it.dueAt }

    var selectedId by remember { mutableStateOf<Long?>(null) }
    val selected = active.firstOrNull { it.id == selectedId }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Hatırlatma Programı", fontWeight = FontWeight.SemiBold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        // Sağ altta sabit "Ekle" düğmesi: liste kayarken yerinde kalır.
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAdd,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Ekle") }
            )
        }
    ) { padding ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 96.dp)
            ) {
                if (!notificationsOn) {
                    item { NotificationBanner(onFixNotifications) }
                }
                if (active.isEmpty()) {
                    item { EmptyState() }
                }
                items(oneTime, key = { it.id }) { r ->
                    ReminderRow(r, now) { selectedId = r.id }
                }
                if (repeating.isNotEmpty()) {
                    item { SectionHeader("Tekrarlı görevler") }
                    items(repeating, key = { it.id }) { r ->
                        ReminderRow(r, now) { selectedId = r.id }
                    }
                }
            }

            // Sol altta sabit "Arşiv" düğmesi.
            ExtendedFloatingActionButton(
                onClick = onArchive,
                icon = { Icon(Icons.Default.List, contentDescription = null) },
                text = { Text("Arşiv") },
                containerColor = MaterialTheme.colorScheme.secondaryContainer,
                contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(16.dp)
            )
        }
    }

    selected?.let { r ->
        ReminderActions(
            r = r,
            onDismiss = { selectedId = null },
            onDone = {
                Engine.complete(ctx, r.id)
                selectedId = null
                val msg = if (r.isRepeating) {
                    "Arşive kaydedildi. Sonraki bildirim planlandığı gibi gelecek."
                } else {
                    "Tamamlandı, arşive taşındı."
                }
                Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
            },
            onEdit = {
                selectedId = null
                onEdit(r.id)
            },
            onCancelRepeat = {
                Engine.cancelRepeat(ctx, r.id)
                selectedId = null
                Toast.makeText(ctx, "Tekrar iptal edildi, arşive taşındı.", Toast.LENGTH_SHORT).show()
            }
        )
    }
}

private fun subtitleFor(r: Reminder, now: Long, overdue: Boolean): String {
    return if (!r.isRepeating) {
        if (overdue) {
            "Süresi geçti: ${Fmt.remaining(r.dueAt, now)} · ${Fmt.dateTime(r.dueAt)}"
        } else {
            "Kalan: ${Fmt.remaining(now, r.dueAt)} · ${Fmt.dateTime(r.dueAt)}"
        }
    } else {
        val next = "Sonraki: ${Fmt.dateTime(r.dueAt)}"
        if (overdue) {
            "Tamamlanmadı (${Fmt.shortDateTime(r.pendingAt)}) · $next"
        } else {
            "$next · ${Fmt.remaining(now, r.dueAt)} kaldı"
        }
    }
}

@Composable
private fun ReminderRow(r: Reminder, now: Long, onClick: () -> Unit) {
    // Süresi geçen görev, tamamlanana kadar kırmızı kalır.
    val overdue = if (r.isRepeating) r.pendingAt != 0L else r.dueAt < now
    val titleColor = if (overdue) OverdueRed else MaterialTheme.colorScheme.onSurface
    val subColor = if (overdue) OverdueRed else MaterialTheme.colorScheme.onSurfaceVariant

    Column(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    text = r.text,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium,
                    color = titleColor
                )
                Text(
                    text = subtitleFor(r, now, overdue),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontSize = 12.sp,
                    color = subColor
                )
            }
            if (r.isRepeating) {
                Spacer(Modifier.width(8.dp))
                Text(
                    text = Fmt.repeatLabel(r.repeat),
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                    modifier = Modifier
                        .background(MaterialTheme.colorScheme.secondaryContainer, RoundedCornerShape(50))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.primaryContainer)
            .padding(horizontal = 16.dp, vertical = 6.dp)
    )
}

@Composable
private fun EmptyState() {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 32.dp, vertical = 64.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Henüz hatırlatma yok", fontSize = 18.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.padding(4.dp))
        Text(
            "Sağ alttaki \"Ekle\" düğmesiyle ilk hatırlatmanı oluştur.",
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun NotificationBanner(onFix: () -> Unit) {
    Surface(color = Color(0xFFFFF3CD), modifier = Modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(start = 16.dp, end = 8.dp, top = 4.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Bildirimler kapalı; hatırlatmalar görünmez.",
                fontSize = 13.sp,
                color = Color(0xFF664D03),
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onFix) { Text("Aç") }
        }
    }
}

/** Satıra tıklayınca açılan işlem penceresi: tamamlandı / düzenle / (tekrarlıysa) tekrarı iptal et. */
@Composable
private fun ReminderActions(
    r: Reminder,
    onDismiss: () -> Unit,
    onDone: () -> Unit,
    onEdit: () -> Unit,
    onCancelRepeat: () -> Unit
) {
    val details = buildString {
        if (r.isRepeating) {
            append(Fmt.repeatDescription(r))
            append("\nSonraki bildirim: ").append(Fmt.dateTime(r.dueAt))
            if (r.pendingAt != 0L) {
                append("\nTamamlanmamış tekrar: ").append(Fmt.dateTime(r.pendingAt))
            }
        } else {
            append("Planlanan: ").append(Fmt.dateTime(r.dueAt))
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
        ) {
            Column(
                Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = r.text,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 6,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = details,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.padding(2.dp))
                Button(onClick = onDone, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Check, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Tamamlandı")
                }
                OutlinedButton(onClick = onEdit, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Edit, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Düzenle")
                }
                if (r.isRepeating) {
                    TextButton(
                        onClick = onCancelRepeat,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.textButtonColors(contentColor = OverdueRed)
                    ) {
                        Text("Tekrarı iptal et")
                    }
                }
                TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) {
                    Text("Kapat")
                }
            }
        }
    }
}
