@file:OptIn(ExperimentalMaterial3Api::class)

package com.hatirlatma.app

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

/** Hem "Ekle" hem de "Düzenle" için kullanılan form. [existing] null ise yeni görev eklenir. */
@Composable
fun EditScreen(existing: Reminder?, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val zone = ZoneId.systemDefault()

    // Varsayılanlar: tarih BUGÜN, saat bir sonraki tam saat (gün sonuna taşarsa 23:59).
    val today = LocalDate.now()
    val nowTime = LocalTime.now()
    val nextHour = nowTime.plusHours(1).withMinute(0).withSecond(0).withNano(0)
    val defaultTime = if (nextHour.isAfter(nowTime)) nextHour else LocalTime.of(23, 59)

    val existingDue: LocalDateTime? =
        if (existing != null && !existing.isRepeating) {
            LocalDateTime.ofInstant(Instant.ofEpochMilli(existing.dueAt), zone)
        } else null

    val initHour = if (existing != null && existing.isRepeating) existing.hour
    else existingDue?.hour ?: defaultTime.hour
    val initMinute = if (existing != null && existing.isRepeating) existing.minute
    else existingDue?.minute ?: defaultTime.minute

    var text by rememberSaveable { mutableStateOf(existing?.text ?: "") }
    var epochDay by rememberSaveable { mutableStateOf((existingDue?.toLocalDate() ?: today).toEpochDay()) }
    var hour by rememberSaveable { mutableStateOf(initHour) }
    var minute by rememberSaveable { mutableStateOf(initMinute) }
    var repeating by rememberSaveable { mutableStateOf(existing?.isRepeating ?: false) }
    var repeatCode by rememberSaveable {
        mutableStateOf(if (existing != null && existing.isRepeating) existing.repeat.code else Repeat.DAILY.code)
    }
    var weekDay by rememberSaveable {
        mutableStateOf(
            if (existing != null && existing.repeat == Repeat.WEEKLY) existing.repeatDay
            else today.dayOfWeek.value
        )
    }
    var monthDay by rememberSaveable {
        mutableStateOf(
            if (existing != null && existing.repeat == Repeat.MONTHLY) existing.repeatDay
            else today.dayOfMonth
        )
    }
    var showDayDialog by rememberSaveable { mutableStateOf(false) }

    val repeatType = Repeat.of(repeatCode)
    val dueMillis = LocalDateTime.of(LocalDate.ofEpochDay(epochDay), LocalTime.of(hour, minute))
        .atZone(zone).toInstant().toEpochMilli()
    val inPast = !repeating && dueMillis < System.currentTimeMillis()

    fun pickDate() {
        val d = LocalDate.ofEpochDay(epochDay)
        DatePickerDialog(
            ctx,
            { _, y, m, day -> epochDay = LocalDate.of(y, m + 1, day).toEpochDay() },
            d.year, d.monthValue - 1, d.dayOfMonth
        ).show()
    }

    fun pickTime() {
        TimePickerDialog(
            ctx,
            { _, h, mi ->
                hour = h
                minute = mi
            },
            hour, minute, true
        ).show()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        if (existing == null) "Yeni hatırlatma" else "Hatırlatmayı düzenle",
                        fontWeight = FontWeight.SemiBold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onClose) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Geri")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text("Hatırlatma metni") },
                minLines = 2,
                maxLines = 5,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                modifier = Modifier.fillMaxWidth()
            )

            // Tekrarlı tiki
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { repeating = !repeating },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(checked = repeating, onCheckedChange = { repeating = it })
                Text("Tekrarlı", fontSize = 16.sp)
            }

            if (!repeating) {
                // Tek seferlik: tarih (varsayılan bugün) ve saat ayrı alanlar
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    FieldButton(
                        caption = "Tarih",
                        value = Fmt.dateWithDay(epochDay),
                        modifier = Modifier.weight(1.6f),
                        onClick = { pickDate() }
                    )
                    FieldButton(
                        caption = "Saat",
                        value = Fmt.time(hour, minute),
                        modifier = Modifier.weight(1f),
                        onClick = { pickTime() }
                    )
                }
                if (inPast) {
                    Text(
                        "Seçtiğin tarih/saat geçmişte. Görev kırmızı görünür, bildirim gelmez.",
                        fontSize = 12.sp,
                        color = OverdueRed
                    )
                }
            } else {
                Text("Ne sıklıkla tekrarlansın?", fontSize = 14.sp, fontWeight = FontWeight.Medium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (type in listOf(Repeat.DAILY, Repeat.WEEKLY, Repeat.MONTHLY)) {
                        FilterChip(
                            selected = repeatType == type,
                            onClick = { repeatCode = type.code },
                            label = { Text(Fmt.repeatLabel(type)) }
                        )
                    }
                }

                if (repeatType == Repeat.WEEKLY) {
                    Text("Haftanın hangi günü?", fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        for (d in 1..7) {
                            FilterChip(
                                selected = weekDay == d,
                                onClick = { weekDay = d },
                                label = { Text(Fmt.dayName(d)) }
                            )
                        }
                    }
                }

                if (repeatType == Repeat.MONTHLY) {
                    FieldButton(
                        caption = "Ayın hangi günü?",
                        value = "Her ayın $monthDay. günü",
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { showDayDialog = true }
                    )
                    if (monthDay > 28) {
                        Text(
                            "Ayda bu gün yoksa (ör. 31) ayın son günü kullanılır.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                FieldButton(
                    caption = "Saat",
                    value = Fmt.time(hour, minute),
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { pickTime() }
                )

                val day = when (repeatType) {
                    Repeat.WEEKLY -> weekDay
                    Repeat.MONTHLY -> monthDay
                    else -> 0
                }
                val first = Recur.next(repeatType, day, hour, minute, System.currentTimeMillis())
                Text(
                    "${Fmt.repeatDescription(repeatType, day, hour, minute)}\nİlk bildirim: ${Fmt.dateTime(first)}",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(Modifier.height(4.dp))

            Button(
                onClick = {
                    val base = existing ?: Reminder(text = "", dueAt = dueMillis)
                    val reminder = if (repeating) {
                        base.copy(
                            text = text.trim(),
                            repeat = repeatType,
                            repeatDay = when (repeatType) {
                                Repeat.WEEKLY -> weekDay
                                Repeat.MONTHLY -> monthDay
                                else -> 0
                            },
                            hour = hour,
                            minute = minute
                        )
                    } else {
                        base.copy(
                            text = text.trim(),
                            repeat = Repeat.NONE,
                            repeatDay = 0,
                            hour = hour,
                            minute = minute,
                            dueAt = dueMillis
                        )
                    }
                    Engine.save(ctx, reminder)
                    onClose()
                },
                enabled = text.isNotBlank(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                Text("Kaydet", fontSize = 16.sp)
            }
        }
    }

    if (showDayDialog) {
        DayOfMonthDialog(
            selected = monthDay,
            onSelect = {
                monthDay = it
                showDayDialog = false
            },
            onDismiss = { showDayDialog = false }
        )
    }
}

@Composable
private fun FieldButton(caption: String, value: String, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier) {
        Text(
            caption,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
        )
        OutlinedButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
            Text(value, fontSize = 15.sp, maxLines = 1)
        }
    }
}

/** 1-31 arası günü takvim gibi bir ızgaradan seçtiren pencere. */
@Composable
private fun DayOfMonthDialog(selected: Int, onSelect: (Int) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ayın hangi günü?") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                for (week in 0 until 5) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        for (i in 1..7) {
                            val d = week * 7 + i
                            if (d <= 31) {
                                DayCell(d, d == selected) { onSelect(d) }
                            } else {
                                Spacer(Modifier.size(38.dp))
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Vazgeç") } }
    )
}

@Composable
private fun DayCell(day: Int, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(if (selected) MaterialTheme.colorScheme.primary else Color.Transparent)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = day.toString(),
            fontSize = 14.sp,
            color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
        )
    }
}
