package com.hatirlatma.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Alarm zamanı gelince çalışır; uygulama kapalı olsa bile sistem bunu tetikler. */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra(Scheduler.EXTRA_ID, -1L)
        if (id < 0) return
        val snooze = intent.getBooleanExtra(Scheduler.EXTRA_SNOOZE, false)
        val app = context.applicationContext
        val result = goAsync()
        Thread {
            try {
                Engine.onFire(app, id, snooze)
            } finally {
                result.finish()
            }
        }.start()
    }
}

/** Bildirimdeki "Tamamlandı" düğmesi. */
class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_DONE) return
        val id = intent.getLongExtra(Scheduler.EXTRA_ID, -1L)
        if (id < 0) return
        val app = context.applicationContext
        val result = goAsync()
        Thread {
            try {
                Engine.complete(app, id)
            } finally {
                result.finish()
            }
        }.start()
    }

    companion object {
        const val ACTION_DONE = "com.hatirlatma.app.DONE"
    }
}

/**
 * Telefon yeniden başlayınca (veya uygulama güncellenince / saat değişince) alarmlar
 * sistem tarafından silinir; burada hepsini yeniden kurarız.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val boot = intent.action == Intent.ACTION_BOOT_COMPLETED
        val app = context.applicationContext
        val result = goAsync()
        Thread {
            try {
                Engine.rescheduleAll(app, boot)
            } finally {
                result.finish()
            }
        }.start()
    }
}
