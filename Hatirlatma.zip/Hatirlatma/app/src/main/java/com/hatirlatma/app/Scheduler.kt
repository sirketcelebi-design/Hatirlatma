package com.hatirlatma.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build

/** AlarmManager ile alarm kurma/iptal etme. Alarmlar uygulama kapalıyken de çalışır. */
object Scheduler {
    const val ACTION_FIRE = "com.hatirlatma.app.FIRE"
    const val EXTRA_ID = "reminder_id"
    const val EXTRA_SNOOZE = "reminder_snooze"

    private fun alarmManager(ctx: Context) = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    private fun pending(ctx: Context, id: Long, snooze: Boolean, create: Boolean): PendingIntent? {
        val intent = Intent(ctx, AlarmReceiver::class.java).apply {
            action = ACTION_FIRE
            data = Uri.parse("hatirlatma://reminder/$id/${if (snooze) "snooze" else "main"}")
            putExtra(EXTRA_ID, id)
            putExtra(EXTRA_SNOOZE, snooze)
        }
        val flags = PendingIntent.FLAG_IMMUTABLE or
            (if (create) PendingIntent.FLAG_UPDATE_CURRENT else PendingIntent.FLAG_NO_CREATE)
        return PendingIntent.getBroadcast(ctx, id.toInt() * 2 + (if (snooze) 1 else 0), intent, flags)
    }

    /** [snooze] true ise tekrarlı görev için ek (tek seferlik) erteleme alarmı kurar. */
    fun schedule(ctx: Context, id: Long, atMillis: Long, snooze: Boolean = false) {
        val am = alarmManager(ctx)
        val pi = pending(ctx, id, snooze, true) ?: return
        try {
            val exact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()
            if (exact) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pi)
        }
    }

    fun cancel(ctx: Context, id: Long) {
        cancelOne(ctx, id, false)
        cancelOne(ctx, id, true)
    }

    fun cancelSnooze(ctx: Context, id: Long) = cancelOne(ctx, id, true)

    private fun cancelOne(ctx: Context, id: Long, snooze: Boolean) {
        val pi = pending(ctx, id, snooze, false) ?: return
        alarmManager(ctx).cancel(pi)
        pi.cancel()
    }
}
