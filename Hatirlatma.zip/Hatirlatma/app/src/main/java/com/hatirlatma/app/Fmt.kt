package com.hatirlatma.app

import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.time.temporal.ChronoUnit
import java.util.Locale

/** Tekrarlı görevlerde bir sonraki zamanı hesaplar. */
object Recur {
    private val zone: ZoneId get() = ZoneId.systemDefault()

    /**
     * [afterMillis] anından KESİNLİKLE sonraki ilk planlı zamanı döndürür.
     * Aylıkta gün ayda yoksa (ör. 31 Şubat) ayın son günü kullanılır.
     */
    fun next(repeat: Repeat, day: Int, hour: Int, minute: Int, afterMillis: Long): Long {
        val after = LocalDateTime.ofInstant(Instant.ofEpochMilli(afterMillis), zone)
        val time = LocalTime.of(hour.coerceIn(0, 23), minute.coerceIn(0, 59))

        val result: LocalDateTime = when (repeat) {
            Repeat.DAILY -> {
                var c = LocalDateTime.of(after.toLocalDate(), time)
                if (!c.isAfter(after)) c = c.plusDays(1)
                c
            }

            Repeat.WEEKLY -> {
                val target = DayOfWeek.of(day.coerceIn(1, 7))
                var date = after.toLocalDate()
                while (date.dayOfWeek != target) date = date.plusDays(1)
                var c = LocalDateTime.of(date, time)
                if (!c.isAfter(after)) c = c.plusDays(7)
                c
            }

            Repeat.MONTHLY -> {
                fun candidate(ym: YearMonth): LocalDateTime {
                    val d = day.coerceIn(1, 31).coerceAtMost(ym.lengthOfMonth())
                    return LocalDateTime.of(ym.atDay(d), time)
                }

                var ym = YearMonth.from(after)
                var c = candidate(ym)
                while (!c.isAfter(after)) {
                    ym = ym.plusMonths(1)
                    c = candidate(ym)
                }
                c
            }

            Repeat.NONE -> after
        }
        return result.atZone(zone).toInstant().toEpochMilli()
    }
}

/** Ekranda görünen yazıların (tarih, kalan süre vb.) hazırlanması. */
object Fmt {
    private val tr = Locale("tr", "TR")
    private val fullFmt = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm")
    private val shortFmt = DateTimeFormatter.ofPattern("dd.MM HH:mm")
    private val dateFmt = DateTimeFormatter.ofPattern("dd.MM.yyyy")

    private fun local(ms: Long): LocalDateTime =
        LocalDateTime.ofInstant(Instant.ofEpochMilli(ms), ZoneId.systemDefault())

    fun dateTime(ms: Long): String = fullFmt.format(local(ms))

    fun shortDateTime(ms: Long): String = shortFmt.format(local(ms))

    fun time(hour: Int, minute: Int): String = String.format(Locale.ROOT, "%02d:%02d", hour, minute)

    fun dayName(isoDay: Int): String =
        DayOfWeek.of(isoDay.coerceIn(1, 7)).getDisplayName(TextStyle.FULL, tr)

    fun dateWithDay(epochDay: Long): String {
        val d = LocalDate.ofEpochDay(epochDay)
        return dateFmt.format(d) + " " + d.dayOfWeek.getDisplayName(TextStyle.FULL, tr)
    }

    fun repeatLabel(repeat: Repeat): String = when (repeat) {
        Repeat.DAILY -> "Günlük"
        Repeat.WEEKLY -> "Haftalık"
        Repeat.MONTHLY -> "Aylık"
        Repeat.NONE -> ""
    }

    fun repeatDescription(repeat: Repeat, day: Int, hour: Int, minute: Int): String {
        val t = time(hour, minute)
        return when (repeat) {
            Repeat.DAILY -> "Her gün $t"
            Repeat.WEEKLY -> "Her ${dayName(day)} $t"
            Repeat.MONTHLY -> "Her ayın $day. günü $t"
            Repeat.NONE -> ""
        }
    }

    fun repeatDescription(r: Reminder): String = repeatDescription(r.repeat, r.repeatDay, r.hour, r.minute)

    /** İki an arasındaki farkı "2 ay 3 gün 4 sa" biçiminde yazar (yönü önemsemez). */
    fun remaining(aMs: Long, bMs: Long): String {
        val from = local(minOf(aMs, bMs))
        val to = local(maxOf(aMs, bMs))

        val months = ChronoUnit.MONTHS.between(from, to)
        val afterMonths = from.plusMonths(months)
        val days = ChronoUnit.DAYS.between(afterMonths, to)
        val afterDays = afterMonths.plusDays(days)
        val hours = ChronoUnit.HOURS.between(afterDays, to)
        val afterHours = afterDays.plusHours(hours)
        val minutes = ChronoUnit.MINUTES.between(afterHours, to)

        val parts = ArrayList<String>()
        if (months > 0) parts.add("$months ay")
        if (days > 0) parts.add("$days gün")
        if (hours > 0) parts.add("$hours sa")
        if (parts.isEmpty()) parts.add(if (minutes > 0) "$minutes dk" else "1 dk'dan az")
        return parts.joinToString(" ")
    }
}
