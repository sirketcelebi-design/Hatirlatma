package com.hatirlatma.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private val notificationsOn = mutableStateOf(true)

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            refreshNotificationState()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notifier.ensureChannel(this)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            HatirlatmaTheme {
                AppRoot(
                    notificationsOn = notificationsOn.value,
                    onFixNotifications = { openNotificationSettings() }
                )
            }
        }
    }

    override fun onStart() {
        super.onStart()
        refreshNotificationState()
        // Alarmlar herhangi bir nedenle silinmişse uygulama her açıldığında yeniden kurulur.
        val app = applicationContext
        Thread { Engine.rescheduleAll(app, boot = false) }.start()
    }

    private fun refreshNotificationState() {
        notificationsOn.value = NotificationManagerCompat.from(this).areNotificationsEnabled()
    }

    private fun openNotificationSettings() {
        val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
        startActivity(intent)
    }
}

/** Basit ekran yönlendirmesi: ana sayfa / ekle-düzenle / arşiv. */
@Composable
fun AppRoot(notificationsOn: Boolean, onFixNotifications: () -> Unit) {
    val ctx = LocalContext.current
    val repo = remember { Repo.of(ctx) }
    val all by repo.state.collectAsState()

    var route by rememberSaveable { mutableStateOf("home") }
    var editId by rememberSaveable { mutableStateOf(0L) }

    when (route) {
        "edit" -> {
            BackHandler { route = "home" }
            EditScreen(
                existing = all.firstOrNull { it.id == editId && it.status == Status.ACTIVE },
                onClose = { route = "home" }
            )
        }

        "archive" -> {
            BackHandler { route = "home" }
            ArchiveScreen(all = all, onBack = { route = "home" })
        }

        else -> HomeScreen(
            reminders = all,
            notificationsOn = notificationsOn,
            onFixNotifications = onFixNotifications,
            onAdd = {
                editId = 0L
                route = "edit"
            },
            onEdit = { id ->
                editId = id
                route = "edit"
            },
            onArchive = { route = "archive" }
        )
    }
}
