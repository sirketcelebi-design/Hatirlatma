package com.hatirlatma.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle

/**
 * Bildirimde "Ertele"ye basınca açılır: ne kadar erteleneceğini sorar.
 * Arka planı şeffaftır, sadece seçenek penceresi görünür.
 */
class SnoozeActivity : Activity() {

    private val options = listOf(
        "5 dakika" to 5,
        "15 dakika" to 15,
        "30 dakika" to 30,
        "1 saat" to 60,
        "3 saat" to 180,
        "Yarın (24 saat sonra)" to 1440
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val id = intent.getLongExtra(Scheduler.EXTRA_ID, -1L)
        val reminder = if (id >= 0) Repo.of(this).get(id) else null
        if (reminder == null || reminder.status != Status.ACTIVE) {
            finish()
            return
        }

        AlertDialog.Builder(this)
            .setTitle("Ne kadar ertelensin?")
            .setItems(options.map { it.first }.toTypedArray()) { _, which ->
                Engine.snooze(applicationContext, id, options[which].second)
                finish()
            }
            .setOnCancelListener { finish() }
            .show()
    }
}
