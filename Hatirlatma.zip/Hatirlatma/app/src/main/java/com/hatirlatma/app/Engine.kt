package com.hatirlatma.app

import android.content.Context

/**
 * Uygulamanın iş kuralları: kaydetme, tamamlama, erteleme, tekrar iptali, arşivden geri alma,
 * alarm tetiklenince yapılacaklar ve yeniden başlatma sonrası alarmların yeniden kurulması.
 * Hem arayüzden hem de bildirim/alarm alıcılarından çağrılır.
 */
object Engine {

    /** Yeni hatırlatma ekler veya mevcut olanı günceller. Alarmı yeniden kurar. */
    fun save(ctx: Context, input: Reminder): Long {
        val repo = Repo.of(ctx)
        val now = System.currentTimeMillis()
        val old = if (input.id != 0L) repo.get(input.id) else null

        val r: Reminder = if (input.isRepeating) {
            // Takvim ayarı değişmediyse ve zaten planlı gelecek bir zaman varsa onu koru.
            val keepDue = old?.takeIf {
                it.isRepeating && it.repeat == input.repeat && it.repeatDay == input.repeatDay &&
                    it.hour == input.hour && it.minute == input.minute && it.dueAt > now
            }?.dueAt
            val due = keepDue ?: Recur.next(input.repeat, input.repeatDay, input.hour, input.minute, now)
            input.copy(dueAt = due, occurrenceAt = due, status = Status.ACTIVE)
        } else {
            input.copy(occurrenceAt = input.dueAt, pendingAt = 0L, status = Status.ACTIVE)
        }

        val id: Long
        if (r.id == 0L) {
            id = repo.insert(r)
        } else {
            Scheduler.cancel(ctx, r.id)
            Notifier.cancel(ctx, r.id)
            repo.update(r)
            id = r.id
        }
        if (r.dueAt > now) Scheduler.schedule(ctx, id, r.dueAt)
        return id
    }

    /**
     * "Tamamlandı".
     * - Tek seferlik: arşive taşınır.
     * - Tekrarlı: o tekrar arşive kayıt olarak eklenir, görev ana sayfada kalır ve bir
     *   sonraki bildirim planlandığı zamanda yine çıkar.
     */
    fun complete(ctx: Context, id: Long) {
        val repo = Repo.of(ctx)
        val r = repo.get(id) ?: return
        if (r.status != Status.ACTIVE) return
        val now = System.currentTimeMillis()
        Notifier.cancel(ctx, id)

        if (!r.isRepeating) {
            Scheduler.cancel(ctx, id)
            repo.update(r.copy(status = Status.DONE, completedAt = now, pendingAt = 0L))
            return
        }

        val hadPending = r.pendingAt != 0L
        val occurrence = if (hadPending) r.pendingAt else r.dueAt
        repo.insert(
            Reminder(
                text = r.text,
                dueAt = occurrence,
                occurrenceAt = occurrence,
                status = Status.DONE,
                completedAt = now
            )
        )

        if (hadPending) {
            // Bildirimi çıkmış tekrar tamamlandı; sonraki tekrar zaten planlı.
            Scheduler.cancelSnooze(ctx, id)
            repo.update(r.copy(pendingAt = 0L))
        } else {
            // Tekrar zamanı gelmeden tamamlandı: o tekrarı atla, bir sonrakini planla.
            Scheduler.cancel(ctx, id)
            val next = Recur.next(r.repeat, r.repeatDay, r.hour, r.minute, maxOf(r.dueAt, now))
            repo.update(r.copy(dueAt = next, occurrenceAt = next))
            Scheduler.schedule(ctx, id, next)
        }
    }

    /** Bildirimden/uygulamadan erteleme. [minutes] kadar sonra tekrar bildirim çıkar. */
    fun snooze(ctx: Context, id: Long, minutes: Int) {
        val repo = Repo.of(ctx)
        val r = repo.get(id) ?: return
        if (r.status != Status.ACTIVE) return
        val at = System.currentTimeMillis() + minutes * 60_000L
        Notifier.cancel(ctx, id)

        if (!r.isRepeating) {
            Scheduler.cancel(ctx, id)
            repo.update(r.copy(dueAt = at))
            Scheduler.schedule(ctx, id, at)
        } else {
            // Tekrarlı görevin düzenli takvimi bozulmaz; sadece ek bir hatırlatma kurulur.
            Scheduler.schedule(ctx, id, at, snooze = true)
        }
    }

    /** Tekrarlı görevi iptal eder: bildirimler durur, görev arşive "iptal edildi" olarak geçer. */
    fun cancelRepeat(ctx: Context, id: Long) {
        val repo = Repo.of(ctx)
        val r = repo.get(id) ?: return
        Scheduler.cancel(ctx, id)
        Notifier.cancel(ctx, id)
        repo.update(
            r.copy(status = Status.CANCELLED, completedAt = System.currentTimeMillis(), pendingAt = 0L)
        )
    }

    /** Arşivdeki görevi ana sayfaya geri alır (yeniden aktif eder). */
    fun restore(ctx: Context, id: Long) {
        val repo = Repo.of(ctx)
        val r = repo.get(id) ?: return
        if (r.status == Status.ACTIVE) return
        val now = System.currentTimeMillis()

        val restored = if (r.isRepeating) {
            val due = Recur.next(r.repeat, r.repeatDay, r.hour, r.minute, now)
            r.copy(status = Status.ACTIVE, completedAt = 0L, pendingAt = 0L, dueAt = due, occurrenceAt = due)
        } else {
            r.copy(status = Status.ACTIVE, completedAt = 0L, pendingAt = 0L)
        }
        repo.update(restored)
        if (restored.dueAt > now) Scheduler.schedule(ctx, restored.id, restored.dueAt)
    }

    fun delete(ctx: Context, id: Long) {
        Scheduler.cancel(ctx, id)
        Notifier.cancel(ctx, id)
        Repo.of(ctx).delete(id)
    }

    /** Alarm zamanı geldi (uygulama kapalıyken de buraya düşer). */
    fun onFire(ctx: Context, id: Long, snoozeAlarm: Boolean) {
        val repo = Repo.of(ctx)
        val r = repo.get(id) ?: return
        if (r.status != Status.ACTIVE) return
        val now = System.currentTimeMillis()

        if (snoozeAlarm) {
            Notifier.show(ctx, r)
            return
        }
        if (r.dueAt > now + EARLY_TOLERANCE_MS) {
            // Eski/erken gelen alarm: doğru zamana yeniden kur.
            Scheduler.schedule(ctx, id, r.dueAt)
            return
        }
        if (!r.isRepeating) {
            Notifier.show(ctx, r)
        } else {
            fireRepeating(ctx, r, now, notify = true)
        }
    }

    /**
     * Tekrarlı görevin bir tekrarı gerçekleşti: o tekrar "bekleyen" olur (kırmızı),
     * bir sonraki tekrar için alarm kurulur. Tamamlanmasa bile sonraki tekrar yine gelir.
     */
    private fun fireRepeating(ctx: Context, r: Reminder, now: Long, notify: Boolean) {
        val occurrence = r.dueAt
        val next = Recur.next(r.repeat, r.repeatDay, r.hour, r.minute, maxOf(now, occurrence))
        val updated = r.copy(pendingAt = occurrence, dueAt = next, occurrenceAt = next)
        Repo.of(ctx).update(updated)
        Scheduler.schedule(ctx, r.id, next)
        if (notify) Notifier.show(ctx, updated)
    }

    /**
     * Tüm aktif görevlerin alarmlarını yeniden kurar.
     * [boot] true ise (telefon yeniden başladı) tamamlanmamış/kaçırılmış görevlerin
     * bildirimleri yeniden gösterilir, böylece yeniden başlatma sonrası bildirim kaybolmaz.
     */
    fun rescheduleAll(ctx: Context, boot: Boolean) {
        val now = System.currentTimeMillis()
        for (r in Repo.of(ctx).queryAll()) {
            if (r.status != Status.ACTIVE) continue
            if (r.isRepeating) {
                if (r.dueAt <= now) {
                    fireRepeating(ctx, r, now, notify = boot)
                } else {
                    Scheduler.schedule(ctx, r.id, r.dueAt)
                    if (boot && r.pendingAt != 0L) Notifier.show(ctx, r)
                }
            } else {
                if (r.dueAt > now) {
                    Scheduler.schedule(ctx, r.id, r.dueAt)
                } else if (boot) {
                    Notifier.show(ctx, r)
                }
            }
        }
    }

    private const val EARLY_TOLERANCE_MS = 60_000L
}
