package com.hatirlatma.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** Süresi geçen görevlerin rengi. */
val OverdueRed = Color(0xFFD32F2F)

private val AppColors = lightColorScheme(
    primary = Color(0xFF0F766E),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCDEBE6),
    onPrimaryContainer = Color(0xFF00201C),
    secondary = Color(0xFF4A635F),
    secondaryContainer = Color(0xFFD5E8E3),
    onSecondaryContainer = Color(0xFF0B1F1C),
    background = Color(0xFFF7FAF9),
    onBackground = Color(0xFF191C1B),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF191C1B),
    surfaceVariant = Color(0xFFDBE5E2),
    onSurfaceVariant = Color(0xFF5A6563),
    outlineVariant = Color(0xFFC3CECB)
)

@Composable
fun HatirlatmaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = AppColors, content = content)
}
